
package productmain;

import com.fpt.nhatnk.pms.ui.ProductConsole;

/**
 *
 * @author Nhat
 */
public class ProductManagement {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ProductConsole pc = new ProductConsole();
        pc.start();
    }
    
}
